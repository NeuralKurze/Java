
package br.com.dds18app.dao;
import java.sql.*;
public class ModuloConexao {
    // Método responsável por estabelecer a conexão com o banco de dados
    public static Connection conector(){
        java.sql.Connection conexao = null;
        
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/dds18app";
        String user = "root";
        String password = "usbw";
        
        // estabelecendo a conexao com o banco
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url,user,password);
            return conexao;
            
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }
}
